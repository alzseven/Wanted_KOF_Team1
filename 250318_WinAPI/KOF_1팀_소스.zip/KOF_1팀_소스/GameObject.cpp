#include "GameObject.h"

void GameObject::Init()
{
}

void GameObject::Release()
{
}

void GameObject::Update()
{
}

void GameObject::Render(HDC hdc)
{
}

GameObject::GameObject()
{
}

GameObject::~GameObject()
{
}
